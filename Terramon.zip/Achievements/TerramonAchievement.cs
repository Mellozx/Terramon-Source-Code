﻿using Terraria.Achievements;
using WebmilioCommons.Achievements;

namespace Terramon.Achievements
{
    public abstract class TerramonAchievement : ModAchievement
    {
        protected TerramonAchievement(string name, string description, AchievementCategory category) : base(name, description, category)
        {
        }
    }
}