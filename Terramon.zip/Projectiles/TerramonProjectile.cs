﻿using Terraria.ModLoader;

namespace Terramon.Projectiles
{
    public abstract class TerramonProjectile : ModProjectile
    {
        
    }
}